@props(['priority'])

@php
$colorClass = match(strtolower($priority)) {
    'scăzută' => 'priority-low',
    'medie' => 'priority-medium',
    'ridicată' => 'priority-high',
    default => 'priority-default'
};

$icon = match(strtolower($priority)) {
    'scăzută' => '▼',
    'medie' => '▶',
    'ridicată' => '▲',
    default => '•'
};
@endphp

<span class="task-priority {{ $colorClass }}">
    <span class="priority-icon">{{ $icon }}</span>
    <span class="priority-text">{{ $priority }}</span>
</span>