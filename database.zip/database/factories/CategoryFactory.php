<?php

namespace Database\Factories;

use App\Models\Category;
use Illuminate\Database\Eloquent\Factories\Factory;

class CategoryFactory extends Factory
{
    protected $model = Category::class;

    public function definition()
    {
        return [
            'name' => fake()->word(),
            'description' => fake()->sentence()
        ];
    }
}


//php artisan make:factory CategoryFactory --model=Category
//php artisan make:factory TaskFactory --model=Task
//php artisan make:factory TagFactory --model=Tag
