<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;

class NoRestrictedWords implements ValidationRule
{
    private $restrictedWords;

    public function __construct(array $restrictedWords = null)
    {
        $this->restrictedWords = $restrictedWords ?? [
            'spam',
            'hate',
            'violence',
            'inappropriate',
            'offensive'
        ];
    }

    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        $lowercaseValue = strtolower($value);
        
        foreach ($this->restrictedWords as $word) {
            if (str_contains($lowercaseValue, $word)) {
                $fail("Câmpul {$attribute} conține cuvântul interzis: '{$word}'.");
            }
        }
    }
}