<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Carbon\Carbon;

class UpdateTaskRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'title' => [
                'required',
                'string',
                'min:3'
            ],
            'description' => [
                'nullable',
                'string',
                'max:500'
            ],
            'due_date' => [
                'required',
                'date',
                'after_or_equal:today'
            ],
            'category_id' => [
                'required',
                'integer',
                'exists:categories,id'
            ],
            'tags' => [
                'nullable',
                'array'
            ],
            'tags.*' => [
                'exists:tags,id'
            ]
        ];
    }

    public function messages()
    {
        return [
            'title.required' => 'Titlul este obligatoriu.',
            'title.min' => 'Titlul trebuie să conțină cel puțin 3 caractere.',
            'description.max' => 'Descrierea nu poate depăși 500 de caractere.',
            'due_date.required' => 'Data limită este obligatorie.',
            'due_date.after_or_equal' => 'Data limită trebuie să fie cel puțin data de astăzi.',
            'category_id.required' => 'Categoria este obligatorie.',
            'category_id.exists' => 'Categoria selectată nu există.',
            'tags.array' => 'Formatul etichetelor este invalid.',
            'tags.*.exists' => 'Una dintre etichetele selectate nu există.'
        ];
    }

    protected function prepareForValidation()
    {
        if ($this->has('due_date')) {
            $this->merge([
                'due_date' => Carbon::parse($this->due_date)->startOfDay()
            ]);
        }
    }
}