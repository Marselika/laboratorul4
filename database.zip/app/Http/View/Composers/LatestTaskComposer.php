<?php

namespace App\Http\View\Composers;

use Illuminate\View\View;

class LatestTaskComposer
{
    public function compose(View $view)
    {
        $tasks = [
            [
                'id' => 1,
                'title' => 'Finalizare proiect',
                'description' => 'Descrierea proiectului 1',
                'status' => 'În progres',
                'created_at' => now()->subDays(5)->format('Y-m-d H:i:s'),
                'updated_at' => now()->subDay()->format('Y-m-d H:i:s'),
                'completed' => false,
                'priority' => 'Ridicată',
                'assigned_to' => 'John Doe'
            ],
            [
                'id' => 2,
                'title' => 'Proiect Nou',
                'description' => 'Descrierea proiectului 2',
                'status' => 'În progres',
                'created_at' => now()->subDays(5)->format('Y-m-d H:i:s'),
                'updated_at' => now()->subDay()->format('Y-m-d H:i:s'),
                'completed' => false,
                'priority' => 'Scăzută',
                'assigned_to' => 'John Doe'
            ],
            [
                'id' => 3,
                'title' => 'Finalizare proiect',
                'description' => 'Descrierea proiectului 3',
                'status' => 'În progres',
                'created_at' => now()->subDays(5)->format('Y-m-d H:i:s'),
                'updated_at' => now()->subDay()->format('Y-m-d H:i:s'),
                'completed' => false,
                'priority' => 'Medie',
                'assigned_to' => 'Jane Smith'
            ],
        ];

        // Luăm ultimul task din array
        $latestTask = end($tasks);
        
        $view->with('latestTask', $latestTask);
    }
}