<?php

namespace App\Http\Controllers;

use App\Models\Task;
use App\Models\Category;
use App\Models\Tag;
use App\Http\Requests\CreateTaskRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\UpdateTaskRequest;

class TaskController extends Controller
{
    public function index()
    {
        $tasks = Task::with(['category', 'tags'])->latest()->get();
        return view('tasks.index', compact('tasks'));
    }

    public function show($id)
    {
        $task = Task::with(['category', 'tags', 'comments'])->findOrFail($id);
        return view('tasks.show', compact('task'));
    }

    public function create()
    {
        $categories = Category::all();
        $tags = Tag::all();
        return view('tasks.create', compact('categories', 'tags'));
    }

    public function store(CreateTaskRequest $request)
    {
        if ($request->isMethod('post')) {  
            return DB::transaction(function () use ($request) {
                $task = Task::create($request->safe()->only([
                    'title',
                    'description',
                    'due_date',
                    'category_id'
                ]));

                if ($request->has('tags')) {
                    $task->tags()->attach($request->validated('tags'));
                }
    
                return redirect()->route('tasks.show', $task->id)
                    ->with('success', 'Sarcina a fost creată cu succes!');
            });
        }
    
        return redirect()->back()->with('error', 'Metoda de trimitere invalidă');
    }
    public function edit($id)
    {
        $task = Task::with(['category', 'tags'])->findOrFail($id);
        $categories = Category::all();
        $tags = Tag::all();
        return view('tasks.edit', compact('task', 'categories', 'tags'));
    }

    public function update(UpdateTaskRequest $request, $id)
    {
        $task = Task::findOrFail($id);

        return DB::transaction(function () use ($request, $task) {
            $task->update($request->safe()->only([
                'title',
                'description',
                'due_date',
                'category_id'
            ]));

            if ($request->has('tags')) {
                $task->tags()->sync($request->validated('tags'));
            } else {
                $task->tags()->detach();
            }

            return redirect()->route('tasks.show', $task->id)
                ->with('success', 'Sarcina a fost actualizată cu succes!');
        });
    }
    public function destroy($id)
    {
        $task = Task::findOrFail($id);
        $task->tags()->detach(); // Elimină relațiile cu tag-urile
        $task->delete();

        return redirect()->route('tasks.index')
            ->with('success', 'Sarcina a fost ștearsă cu succes!');
    }

        public function showComments($taskId)
    {
        $task = Task::with('comments')->findOrFail($taskId);
        return view('tasks.comments.index', compact('task'));
    }

    public function addComment(Request $request, $taskId)
    {
        $task = Task::findOrFail($taskId);
        
        $comment = $task->comments()->create([
            'content' => $request->input('content')
        ]);

        return redirect()->back()->with('success', 'Comentariul a fost adăugat cu succes!');
    }

    public function showComment($taskId, $commentId)
    {
        $task = Task::findOrFail($taskId);
        $comment = $task->comments()->findOrFail($commentId);
        
        return view('tasks.comments.show', compact('task', 'comment'));
    }
}