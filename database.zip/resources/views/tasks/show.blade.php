@extends('layouts.app')

@section('title', 'Detalii sarcină')

@section('content')
<div class="container">
    <x-task-card :task="$task" />

    <div class="comments-section">
        <h3>Adaugă un comentariu</h3>
        <form action="{{ route('tasks.comments.store', $task->id) }}" method="POST">
            @csrf
            <div class="form-group">
                <textarea name="content" class="form-control" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Adaugă comentariu</button>
        </form>

        <div class="comments-list">
            @if($task->comments->count() > 0)
                <h3>Comentarii ({{ $task->comments->count() }})</h3>
                @foreach($task->comments as $comment)
                    <div class="comment-card">
                        <p>{{ $comment->content }}</p>
                        <small>{{ $comment->created_at->diffForHumans() }}</small>
                    </div>
                @endforeach
            @else
                <p>Nu există comentarii încă.</p>
            @endif
        </div>
    </div>

    <div class="mt-4">
        <a href="{{ route('tasks.index') }}" class="btn btn-secondary">Înapoi la lista de sarcini</a>
    </div>
</div>
@endsection