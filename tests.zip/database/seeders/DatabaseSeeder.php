<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Category;
use App\Models\Task;
use App\Models\Tag;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        // Creează 5 categorii
        Category::factory(5)->create();

        // Creează 10 tag-uri
        Tag::factory(10)->create();

        // Creează 20 task-uri și atașează tag-uri aleatorii
        Task::factory(20)
            ->create()
            ->each(function ($task) {
                $task->tags()->attach(
                    Tag::inRandomOrder()->take(rand(1, 3))->pluck('id')
                );
            });
    }
}

//php artisan db:seed