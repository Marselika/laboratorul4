@extends('layouts.app')

@section('title', 'Creează Sarcină Nouă')

@section('content')
<div class="container">
    <h1>Creează Sarcină Nouă</h1>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('tasks.store') }}" method="POST" class="needs-validation" novalidate>
        @csrf
        
        <div class="mb-3">
            <label for="title" class="form-label">Titlu <span class="text-danger">*</span></label>
            <input type="text" 
                   class="form-control @error('title') is-invalid @enderror" 
                   id="title" 
                   name="title" 
                   value="{{ old('title') }}"
                   minlength="3"
                   required>
            @error('title')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Descriere</label>
            <textarea class="form-control @error('description') is-invalid @enderror" 
                      id="description" 
                      name="description" 
                      rows="3"
                      maxlength="500">{{ old('description') }}</textarea>
            @error('description')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
            <div class="form-text">Maxim 500 caractere</div>
        </div>

        <div class="mb-3">
            <label for="due_date" class="form-label">Data limită <span class="text-danger">*</span></label>
            <input type="date" 
                   class="form-control @error('due_date') is-invalid @enderror" 
                   id="due_date" 
                   name="due_date"
                   value="{{ old('due_date') }}"
                   min="{{ date('Y-m-d') }}"
                   required>
            @error('due_date')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="category_id" class="form-label">Categoria <span class="text-danger">*</span></label>
            <select class="form-control @error('category_id') is-invalid @enderror" 
                    id="category_id" 
                    name="category_id"
                    required>
                <option value="">Selectează categoria</option>
                @foreach($categories as $category)
                    <option value="{{ $category->id }}" 
                            {{ old('category_id') == $category->id ? 'selected' : '' }}>
                        {{ $category->name }}
                    </option>
                @endforeach
            </select>
            @error('category_id')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label class="form-label d-block">Etichete</label>
            <div class="row g-2">
                @foreach($tags as $tag)
                    <div class="col-auto">
                        <div class="form-check">
                            <input class="form-check-input" 
                                   type="checkbox" 
                                   name="tags[]" 
                                   value="{{ $tag->id }}" 
                                   id="tag{{ $tag->id }}"
                                   {{ in_array($tag->id, old('tags', [])) ? 'checked' : '' }}>
                            <label class="form-check-label" for="tag{{ $tag->id }}">
                                {{ $tag->name }}
                            </label>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save me-1"></i> Creează Sarcina
            </button>
            <a href="{{ route('tasks.index') }}" class="btn btn-secondary">
                <i class="fas fa-times me-1"></i> Anulează
            </a>
        </div>
    </form>
</div>

@push('scripts')
<script>
// Script pentru validare în timp real
(function () {
    'use strict'
    var forms = document.querySelectorAll('.needs-validation')
    Array.prototype.slice.call(forms)
        .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }
                form.classList.add('was-validated')
            }, false)
        })
})()
</script>
@endpush
@endsection