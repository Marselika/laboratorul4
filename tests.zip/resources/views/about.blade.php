@extends('layouts.app')

@section('title', 'Despre noi')

@section('content')
    <h1>Despre To-Do App pentru echipe</h1>
    <p>Suntem dedicați îmbunătățirii productivității echipelor prin oferirea unei soluții simple și eficiente de gestionare a sarcinilor.</p>

    <h2>Misiunea noastră</h2>
    <p>Să simplificăm gestionarea proiectelor și să îmbunătățim colaborarea în cadrul echipelor de toate dimensiunile.</p>

    <h2>Echipa noastră</h2>
    <p>Suntem un grup de dezvoltatori pasionați care cred în puterea organizării și a colaborării eficiente.</p>

    <h2>Contactează-ne</h2>
    <p>Ai întrebări sau sugestii? Nu ezita să ne contactezi la adresa: support@todoapp.com</p>
@endsection