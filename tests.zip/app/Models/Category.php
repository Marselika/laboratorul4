<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;  // Adăugat

class Category extends Model
{
    use HasFactory;  // Adăugat
    
    protected $fillable = ['name', 'description'];

    public function tasks()
    {
        return $this->hasMany(Task::class);
    }
}

//php artisan make:model Category -m
//php artisan make:model Task -m
//php artisan make:model Tag -m