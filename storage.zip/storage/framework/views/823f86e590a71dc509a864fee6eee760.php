<header>
    <div class="container">
        <h1><?php echo e($title ?? 'Todo App'); ?></h1>
        <nav>
            <ul>
                <li><a href="<?php echo e(route('home')); ?>">Acasă</a></li>
                <li><a href="<?php echo e(route('tasks.index')); ?>">Sarcini</a></li>
                <li><a href="<?php echo e(route('about')); ?>">Despre</a></li>
            </ul>
        </nav>
    </div>
</header><?php /**PATH C:\xampp\todo-app\resources\views/components/header.blade.php ENDPATH**/ ?>